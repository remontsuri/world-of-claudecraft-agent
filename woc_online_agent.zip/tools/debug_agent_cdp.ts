// Agent Bridge: live browser World of Claudecraft <-> agent (Scripted or PPO).
//
// Architecture (single bridge, swappable policy):
//   Browser (vite :5173, Play Offline)
//     window.__game.sim  --(page.evaluate)-->  encodeObs(sim) -> obs(567)
//                                             -> agent.decide(obs) -> action
//     window.__game.controller.move/face + sim.targetNearestEnemy/startAutoAttack
//                                             <- action applied
//     HUD telemetry  --(SSE :8777)-->  debug/debug_hud.html
//
// The obs encoder is the SAME encodeObs the headless env uses (src/sim/obs.ts),
// so a PPO model trained headless transfers to the live character unchanged.
//
// Usage:
//   node dist-tools/debug_agent_cdp.cjs --mode scripted
//   node dist-tools/debug_agent_cdp.cjs --mode ppo --model D:/woc-llm/models/woc_ppo_therock.zip
//
// Assumes the game is already running at --url (pnpm run dev + pnpm run server).

import puppeteer from 'puppeteer-core';
import path from 'node:path';
import { encodeObs, NUM_ACTIONS, ACTIONS } from '../src/sim/obs';
import { ScriptedController, type TargetInfo } from './agent/scripted_agent';
import { PPOClient } from './agent/ppo_client';

const ARGS = process.argv.slice(2);
function arg(name: string, def?: string): string | undefined {
  const i = ARGS.indexOf(`--${name}`);
  return i >= 0 ? ARGS[i + 1] : def;
}
const MODE = (arg('mode', 'scripted') as 'scripted' | 'ppo');
const GAME_URL = arg('url', 'http://localhost:5173');
const HUD_PORT = parseInt(arg('hud-port', '8777') || '8777', 10);
const PPO_URL = arg('ppo-url', 'http://127.0.0.1:5000/predict');
const TICK_HZ = parseInt(arg('hz', '10') || '10', 10);

// --- SSE HUD telemetry server (same port the HUD polls) -------------------
import http from 'node:http';
let latest: any = null;
const sseClients = new Set<http.ServerResponse>();
const hudServer = http.createServer((req, res) => {
  if (req.url === '/stream') {
    res.writeHead(200, {
      'content-type': 'text/event-stream',
      'cache-control': 'no-cache',
      connection: 'keep-alive',
    });
    sseClients.add(res);
    req.on('close', () => sseClients.delete(res));
    return;
  }
  if (req.url === '/latest') {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify(latest ?? {}));
    return;
  }
  res.writeHead(200, { 'content-type': 'text/html' });
  res.end('WoC Agent Bridge HUD endpoint. Open debug/debug_hud.html');
});
function broadcast() {
  const payload = `data: ${JSON.stringify(latest)}\n\n`;
  for (const c of sseClients) c.write(payload);
}
hudServer.listen(HUD_PORT, () => console.log(`[bridge] HUD SSE on :${HUD_PORT}`));

// --- agent selection ------------------------------------------------------
const scripted = new ScriptedController();
const ppo = MODE === 'ppo' ? new PPOClient(PPO_URL) : null;
if (MODE === 'ppo' && !ppo) throw new Error('ppo mode requires ppo_server running');

// --- browser connect -------------------------------------------------------
async function main() {
  const browser = await puppeteer.connect({ browserURL: 'http://127.0.0.1:9222' });
  const pages = await browser.pages();
  let page = pages.find(
    (p) => p.url().includes('worldofclaudecraft.com') || p.url().includes('localhost'),
  );
  if (!page) {
    page = await browser.newPage();
    await page.goto(GAME_URL, { waitUntil: 'networkidle2', timeout: 60000 });
  }
  page.on('console', (m) => {
    const t = m.text();
    if (t.includes('[woc-agent]')) console.log(t);
  });
  console.log(`[bridge] attached to ${page.url()}`);

  // wait for the game to expose window.__game
  await page.waitForFunction('!!window.__game && !!window.__game.sim', { timeout: 60000 });
  console.log('[bridge] window.__game ready');

  // Inject the obs encoder bundle so encodeObs is available in-page even on the
  // online build (window.__game.encodeObs is not exposed there).
  await page.addScriptTag({ path: path.resolve(__dirname, 'obs_bundle.js') });
  await page.waitForFunction(
    '!!window.WOC_OBS && typeof window.WOC_OBS.encodeObs === "function"',
    { timeout: 20000 },
  );
  console.log('[bridge] obs encoder injected');

  const actionNames = ACTIONS as readonly string[];
  let step = 0;
  const intervalMs = Math.max(20, Math.round(1000 / TICK_HZ));

  const loop = setInterval(async () => {
    try {
      const result = await page.evaluate(() => {
        const g = (window as any).__game;
        const sim = g.sim;
        if (!sim) return null;
        const p = sim.player;
        // Online build exposes no spatial grid; shim forEachInRadius via entities
        // so encodeObs (sources from obs.ts) runs unchanged.
        if (!sim.grid) {
          sim.grid = {
            forEachInRadius(x: number, z: number, r: number, cb: (e: any, d2: number) => void) {
              const r2 = r * r;
              for (const e of sim.entities.values()) {
                const dx = e.pos.x - x, dz = e.pos.z - z;
                const d2 = dx * dx + dz * dz;
                if (d2 <= r2) cb(e, d2);
              }
            },
          } as any;
        }
        // encode obs via the injected encoder (window.__game.encodeObs is not on online build)
        const obs = (window as any).WOC_OBS ? (window as any).WOC_OBS.encodeObs(sim) : null;

        // target + nearby mobs for HUD
        const tgt =
          p.targetId != null ? (sim.entities.get(p.targetId) ?? null) : null;
        const mobs: any[] = [];
        for (const e of sim.entities.values()) {
          if (e.kind === 'mob' && !e.dead) {
            const dx = e.pos.x - p.pos.x;
            const dz = e.pos.z - p.pos.z;
            const dist = Math.hypot(dx, dz);
            if (dist < 60) {
              let ang = (Math.atan2(dx, -dz) * 180) / Math.PI - (p.facing * 180) / Math.PI;
              ang = ((ang + 180) % 360 + 360) % 360 - 180;
              mobs.push({
                dist,
                off_deg: ang,
                hp: (e.hp / Math.max(1, e.maxHp)) * 100,
                aggro: e.aggro ?? false,
              });
            }
          }
        }
        mobs.sort((a, b) => a.dist - b.dist);
        let target: any = null;
        if (tgt) {
          const dx = tgt.pos.x - p.pos.x;
          const dz = tgt.pos.z - p.pos.z;
          const dist = Math.hypot(dx, dz);
          let off = (Math.atan2(dx, -dz) * 180) / Math.PI - (p.facing * 180) / Math.PI;
          off = ((off + 180) % 360 + 360) % 360 - 180;
          target = {
            has: true,
            dist,
            off_deg: off,
            hp: (tgt.hp / Math.max(1, tgt.maxHp)) * 100,
            id: p.targetId,
          };
        }
        return {
          obs,
          target,
          mobs: mobs.slice(0, 5),
          player: {
            hp: (p.hp / Math.max(1, p.maxHp)) * 100,
            level: p.level,
            xp: sim.xp,
            facing_deg: (p.facing * 180) / Math.PI,
            px: p.pos.x,
            pz: p.pos.z,
            in_combat: p.inCombat,
            auto_attack: p.autoAttack,
          },
          counters: {
            damage: sim.counters?.damageDealt ?? 0,
            hits: sim.counters?.hitsDealt ?? 0,
            kills: sim.counters?.kills ?? 0,
            deaths: sim.counters?.deaths ?? 0,
          },
        };
      });

      if (!result || !result.obs) return;
      const { obs, target, mobs, player, counters } = result;

      // decide
      let action: number;
      let stateLabel: string;
      if (MODE === 'ppo' && ppo) {
        [action, stateLabel] = await ppo.decide(obs);
      } else {
        [action, stateLabel] = scripted.decide(obs, target as TargetInfo | null);
      }
      const actionName = actionNames[action] ?? `act${action}`;

      // apply action to live sim
      await page.evaluate(
        (a: number) => {
          const g = (window as any).__game;
          const sim = g.sim;
          const name = g.ACTIONS?.[a] ?? null;
          // movement via controller (priority over keyboard)
          if (name === 'forward') g.controller.move({ forward: true });
          else if (name === 'back') g.controller.move({ back: true });
          else if (name === 'turn_left')
            g.controller.move({ turnLeft: true, forward: true });
          else if (name === 'turn_right')
            g.controller.move({ turnRight: true, forward: true });
          else if (name === 'strafe_left') g.controller.move({ strafeLeft: true });
          else if (name === 'strafe_right') g.controller.move({ strafeRight: true });
          else if (name === 'jump') g.controller.move({ jump: true, forward: true });
          else g.controller.stop(); // non-movement action clears move input
          // discrete sim actions
          if (name === 'target_nearest') sim.targetNearestEnemy();
          else if (name === 'attack') sim.startAutoAttack();
          else if (name === 'stop') sim.stopAutoAttack();
          else if (name === 'interact') sim.interact();
        },
        action,
      );

      // HUD telemetry
      latest = {
        step: ++step,
        mode: MODE,
        state: stateLabel,
        action_idx: action,
        action_name: actionName,
        last_actions: [{ idx: action, name: actionName }],
        hp: player.hp,
        level: player.level,
        xp: player.xp,
        facing_deg: player.facing_deg,
        px: player.px,
        pz: player.pz,
        in_combat: player.in_combat,
        auto_attack: player.auto_attack,
        damage: counters.damage,
        hits: counters.hits,
        kills: counters.kills,
        deaths: counters.deaths,
        reward: 0,
        episode_reward: 0,
        target,
        mobs,
      };
      broadcast();
    } catch (err) {
      console.error('[bridge] loop error:', err);
    }
  }, intervalMs);

  process.on('SIGINT', () => {
    clearInterval(loop);
    browser.disconnect();
    process.exit(0);
  });
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
