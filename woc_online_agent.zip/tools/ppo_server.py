"""Minimal PPO inference server for the browser Agent Bridge (BC-B1 variant).

Uses only the Python stdlib (http.server) -- no Flask dependency needed.

The trained SB3 model (from train_ppo_full.py) expects a 568-dim obs: the
original 567 from encodeObs PLUS the derived in_combat_range feature (hysteresis
latch). This server wraps it so the browser bridge (which sends 567) gets a
correct 568-dim prediction without duplicating the obs encoder.

Run:  python tools/ppo_server.py --model nav_data/ppo_from_b1_full.zip
Bridge: tools/debug_agent_cdp.ts --mode ppo --ppo-url http://127.0.0.1:5000/predict
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


def _json_default(o):
    # numpy scalar / array -> python native (defensive; int() casts above cover obs_size)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    return str(o)


_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_ROOT, "python"))

import numpy as np  # noqa: E402  (used by _json_default)

from ppo_agent_b1 import PPOAgentB1


class Handler(BaseHTTPRequestHandler):
    agent: PPOAgentB1 = None  # class-level, set in main()

    def _json(self, obj, code=200):
        body = json.dumps(obj, default=_json_default).encode("utf-8")
        self.send_response(code)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            self._json({"ok": True, "obs_size": self.agent.obs_size,
                        "num_actions": self.agent.num_actions})
        else:
            self._json({"ok": False, "error": "not found"}, 404)

    def do_POST(self):
        length = int(self.headers.get("content-length", 0))
        raw = self.rfile.read(length) if length else b"{}"
        try:
            body = json.loads(raw.decode("utf-8") or "{}")
        except Exception as e:
            self._json({"ok": False, "error": f"bad json: {e}"}, 400)
            return
        if self.path == "/predict":
            obs = body.get("obs")
            if obs is None:
                self._json({"ok": False, "error": "missing obs"}, 400)
                return
            action, label = self.agent.decide(obs)
            self._json({"action": action, "label": label})
        elif self.path == "/reset":
            self.agent.reset_tracker()
            self._json({"ok": True})
        else:
            self._json({"ok": False, "error": "not found"}, 404)

    def log_message(self, *args):
        pass  # quiet

    def handle_error(self, request, client_address):
        import traceback
        sys.stderr.write("=== handler error ===\n")
        traceback.print_exc(file=sys.stderr)
        sys.stderr.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=os.path.join(_ROOT, "python", "nav_data", "ppo_from_b1_full.zip"))
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5000)
    args = ap.parse_args()

    agent = PPOAgentB1(args.model)
    Handler.agent = agent
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"[ppo_server] loaded {args.model} | obs_size={agent.obs_size} "
          f"| listening {args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()


if __name__ == "__main__":
    main()
