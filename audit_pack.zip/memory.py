"""Experience / Memory store — the learning loop's long-term memory.

Per user 2026-08-16 directive: the agent must LEARN from outcomes, not follow a
scripted if/else. This store records (state, decision, outcome, reward) and
adjusts the policy's action weights so that bad choices in a given state become
less likely next time. Death/penalty at low HP teaches "farm while low is bad"
WITHOUT a hard-coded `if HP<30: heal` rule — the agent discovers it.

Design:
- State is bucketed into coarse features (discretized) so experiences generalize.
- Each (state_bucket, action) has a weight = expected value estimate.
- After each step we get a reward (from verifier/outcome). We do a tiny
  tabular TD-ish update: weight += lr * (reward - weight). Positive rewards raise
  the weight, negative (death=-5) lower it.
- Policy samples actions proportional to weight (softmax over the candidate set),
  so it CAN still explore (and occasionally repeat a mistake — that's fine, it's
  how the value estimate stays honest).
"""

import json
import math
import os
from collections import defaultdict
from typing import Dict, List, Optional, Tuple


# ---- state discretization ----------------------------------------------------
def _bucket(state: dict) -> str:
    """Coarse, comparable state key. Intentionally LOSSY so experiences transfer.

    state keys we care about (from WorldState):
      hp_frac      (0..1)
      quest_status (NONE / ACTIVE / READY_TO_TURN_IN / DONE)
      has_mob      (bool)   — hostile mob in nearby
      has_corpse   (bool)   — lootable corpse in nearby
      has_junk     (bool)   — junk-quality item in inventory
      danger       (bool)   — player in combat / low hp
      far          (bool)   — distance_to_giver > 80 (OBSERVED, not a rule)
      combat       (bool)   — in_combat (OBSERVED, not a rule)
    """
    hp = state.get("hp_frac", 1.0)
    hp_band = "crit" if hp < 0.25 else "low" if hp < 0.5 else "ok" if hp < 0.8 else "full"
    qs = state.get("quest_status", "NONE")
    dist = state.get("distance_to_giver", 0.0)
    far = 1 if (dist is not None and dist > 80) else 0
    combat = 1 if state.get("in_combat") else 0
    return "|".join([
        f"hp={hp_band}",
        f"qs={qs}",
        f"mob={1 if state.get('has_mob') else 0}",
        f"corpse={1 if state.get('has_corpse') else 0}",
        f"junk={1 if state.get('has_junk') else 0}",
        f"danger={1 if state.get('danger') else 0}",
        f"far={far}",
        f"combat={combat}",
    ])


class ExperienceStore:
    """Tabular value memory over (state_bucket, action)."""

    def __init__(self, lr: float = 0.2, decay: float = 0.999, path: Optional[str] = None):
        # (bucket, action) -> float value estimate
        self.weights: Dict[Tuple[str, str], float] = defaultdict(float)
        # (bucket, action) -> count (for confidence / exploration bonus)
        self.counts: Dict[Tuple[str, str], int] = defaultdict(int)
        # experience log: (bucket, action, reward, next_bucket, outcome_kind)
        # This is the REAL memory the user wants: not "farm is bad" but
        # "in a similar state I did farm -> X happened -> -0.48 -> P(farm) dropped".
        self.experiences: List[Tuple[str, str, float, str, str]] = []
        self.lr = lr
        self.decay = decay
        self.path = path or os.path.join(os.path.dirname(__file__), "experience.json")
        self._load()

    # ---- persistence ----
    def _load(self):
        """Restore weights/counts/experiences written by save().

        save() serializes weights/counts as a LIST of [key, value] pairs
        ([[bucket, action], value]). The previous implementation called
        `.items()` on that list, raising AttributeError which the bare
        `except Exception: pass` swallowed — so memory silently started EMPTY
        on every load and nothing ever persisted across runs. Parse the list
        form (and tolerate a dict for forward/backward compat).
        """
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            return  # unreadable/corrupt file -> fresh memory

        def _pairs(raw):
            if isinstance(raw, dict):
                return raw.items()
            return [(k, v) for k, v in (raw or [])]

        self.weights = defaultdict(float, {
            tuple(k): float(v) for k, v in _pairs(data.get("weights"))
        })
        self.counts = defaultdict(int, {
            tuple(k): int(v) for k, v in _pairs(data.get("counts"))
        })
        self.experiences = [
            (b, a, float(r), nb, ok)
            for (b, a, r, nb, ok) in (data.get("experiences") or [])
        ]

    def save(self):
        try:
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump({
                    "weights": [[list(k), v] for k, v in self.weights.items()],
                    "counts": [[list(k), v] for k, v in self.counts.items()],
                    "experiences": [[b, a, r, nb, ok] for (b, a, r, nb, ok) in self.experiences[-500:]],
                }, f, ensure_ascii=False, indent=1)
        except Exception:
            pass

    # ---- core API ----
    def value(self, bucket: str, action: str) -> float:
        return self.weights.get((bucket, action), 0.0)

    def record(self, state: dict, action: str, reward: float, next_state: dict, outcome_kind: str = "OK"):
        """Append a full experience tuple: (bucket, action, reward, next_bucket,
        outcome_kind). This is the agent's actual memory — what it did, what
        happened, what it got. The value table is derived from these."""
        bucket = _bucket(state)
        next_bucket = _bucket(next_state)
        self.experiences.append((bucket, action, round(reward, 4), next_bucket, outcome_kind))

    def update(self, state: dict, action: str, reward: float, next_state: dict = None, outcome_kind: str = "OK"):
        """Record one (state, action, reward) and shift the value estimate.

        Tiny TD-style update: the weight moves toward the observed reward.
        Negative reward (e.g. death=-5) pushes it down; positive raises it."""
        bucket = _bucket(state)
        key = (bucket, action)
        self.counts[key] += 1
        w = self.weights[key]
        # move a fraction (lr) of the way from current estimate toward reward
        self.weights[key] = w + self.lr * (reward - w)
        # slow decay of all weights so very old lessons fade (keeps policy adaptive)
        for k in self.weights:
            self.weights[k] *= self.decay
        # record the experience for real memory / analysis
        if next_state is not None:
            self.record(state, action, reward, next_state, outcome_kind)
        self.save()

    def candidate_values(self, state: dict, actions: List[str]) -> Dict[str, float]:
        bucket = _bucket(state)
        return {a: self.value(bucket, a) for a in actions}

    def snapshot(self) -> dict:
        """Human-readable view of what the agent has learned (for logging/debug)."""
        out = {}
        for (bucket, action), w in self.weights.items():
            if abs(w) < 0.05:
                continue
            out.setdefault(bucket, {})[action] = round(w, 3)
        return out
